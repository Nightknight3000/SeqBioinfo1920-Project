from src.main import main

main()
